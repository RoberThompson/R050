#include <Wire.h> //For I2C comm
#include <Adafruit_GFX.h>
#include <LedHelper.h>
#include "Adafruit_LEDBackpack.h"
#include "Adafruit_LiquidCrystal.h"
#include<SPI.h>//serial peripheral interface
#include<Ethernet3.h>//for ethernet
#include<ArduinoRS485.h> //ArduinoModbus depends on the ArduinoRS485 lib
#include<ArduinoModbus.h>//for modbus tcp/ip
#include<ModbusMaster.h>//for oci417.10 rs485 interface with BMM
#include<EEPROM.h>

#include<pid.h>

#ifndef R050_h
#define R050_h

class R050{
private:

public:
  void steamGenPID();
  void superheatTest();
  void connect_IO_Expanders();
  void readPTs();
  void readTCs();//used DB_TX in here in last case.
  void readOut();
  void integrityCheck();
  void readOCI();
  void readBtn();
  void error_Checker();
  void steamPressureLow();
  void monitor_SR_Tube_Temps();
  void blinkGRN();
  void blinkAMB();
  void DB_RX();
  void DB_TX();
  void DB_INIT();
};

#endif
